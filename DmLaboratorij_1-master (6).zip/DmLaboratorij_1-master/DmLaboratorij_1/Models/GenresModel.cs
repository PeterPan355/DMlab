﻿
namespace DmLaboratorij_1.Models
{
    public class GenresModel
    {
        public object _id { get; set; }

        public string genre_id{ get; set; }

        public string genre_type { get; set; }
    }
}
